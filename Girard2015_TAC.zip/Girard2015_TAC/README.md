# IEEE TAC 15
This folder contains MATLAB codes for performing a numerical simulation on Example of the paper. 

Antoine Girard,"Dynamic Triggering Mechanisms for Event-Triggered Control",IEEE TAC, vol.60, no.7, pp. 1992-1997, 2015. 
