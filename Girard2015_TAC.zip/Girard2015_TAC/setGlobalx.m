function setGlobalx(val) % store
global x
x = val;
end