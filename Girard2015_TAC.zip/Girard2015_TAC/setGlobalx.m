function setGlobalx(val) % 存储
global x
x = val;
end