%% System Dynamic Function

function dx = SLSfunc(t,swi_t,x,x_temp)
% Input arguments: time, system's switching signal，system state，sampled state
% Output arguments: derivative of state

A1=[1 0;0 -1];B1=[1;0];K1=[-2 0]; % system matrices
A2=[0 1;-1 0];B2=[0;1];K2=[0 -1];

switch swi_t   % system's switching signal
    case 1
        A=A1;B=B1;
    case 2
        A=A2;B=B2;
end
switch x_temp(4)  % controller's switching signal
    case 1
        K=K1;
    case 2
        K=K2;
end
dx=A*x+B*K*x_temp(2:3); % system dynamic function

