%% 产生切换信号
function swi_t = SwiFcn_ASDC (swi_seq,t)
% 输入：切换时刻序列swi_seq,时间t
% 输出：切换信号swi_t
swi_t=t;
swi_temp=zeros(1,length(swi_seq)); % 切换信号
%-----------------------------------------------------产生切换信号
for r=1:length(swi_seq)
    swi_temp(r)=find(abs(swi_t-swi_seq(r))<0.00001);
end
swi_t(swi_temp)=0; % 将切换时刻置0
temp=0;
for s=1:length(t)
    if(swi_t(s)==0)
        temp=temp+1;
        if(mod(temp,2)==1)
            swi_t(s)=2; % 初始子系统
        else
            swi_t(s)=1;
        end
    else
        swi_t(s)=swi_t(s-1);
    end
end
swi_t=[t;swi_t];