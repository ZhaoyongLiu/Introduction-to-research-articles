%% Dynamic event-triggered control
function [dx,deta] = Dynamic_ETC2015(t,x,eta)
global trigger_times_Dyn;
A = [0 1; -2 3];  % system matrix
B = [0; 1];       
K = [1 -4];       % feedback matrix
P=[1 0.25;0.25 1];
Q=[0.5 0.25;0.25 1.5];
xt = getGlobalx;
e = xt-x;
sigma=0.1; % event triggering parameter
kappa=0.48;
lambda=(1-sigma)*kappa;
a=norm(A+B*K);
theta=1/(2*a-lambda);
if eta+theta*(sigma*x'*Q*x-2*x'*P*B*K*e)<0  % dynamic event triggering condition
   setGlobalx(x); 
   trigger_times_Dyn=[trigger_times_Dyn,t];
end
xt = getGlobalx;
u = K*xt;
dx=A*x+B*u;
deta=-lambda*eta+sigma*x'*Q*x-2*x'*P*B*K*e;
end