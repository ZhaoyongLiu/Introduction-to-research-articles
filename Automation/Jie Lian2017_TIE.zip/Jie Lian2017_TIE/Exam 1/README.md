# IEEE TIE 17
This folder contains MATLAB codes for performing a numerical simulation on Example 1 of the paper. 

Jie Lian,Can Li,and Biao Xia,"Sampled-Data Control of Switched Linear Systems With Application to an F-18 Aircraft",IEEE TIE, vol.64, no.2, pp. 1332-1340, 2017. 
