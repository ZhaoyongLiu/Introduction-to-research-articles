function r = getGlobalx     % read
global x;
r = x;
end
