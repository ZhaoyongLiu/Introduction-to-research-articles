%% Self-triggered control
function dx = Self_ETC2015(t,x)
global trigger_times_Self;
A = [0 1; -2 3];  % system matrix
B = [0; 1];       
K = [1 -4];       % feedback matrix
P=[1 0.25;0.25 1];
Q=[0.5 0.25;0.25 1.5];
xt = getGlobalx;
e = xt-x;
sigma=0.1; % event triggering parameter
kappa=0.48;
V=x'*P*x;Vt=xt'*P*xt;
tk=trigger_times_Self(end);
if V-exp((sigma-1)*kappa*(t-tk))*Vt>0  % self-triggering condition
   setGlobalx(x); 
   trigger_times_Self=[trigger_times_Self,t];
end
xt = getGlobalx;
u = K*xt;
dx=A*x+B*u;
end