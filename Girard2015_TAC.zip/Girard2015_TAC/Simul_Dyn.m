%%
function [t,x,eta,V,W]=Simul_Dyn(ufunc,tspan,x0,h)
% 功能：前向Euler法求解微分方程
% 输入参数：微分方程组的函数名称ufun，时间起点终点tspan,初始值x0，步长h
% 输出参数：时间序列t，状态序列x，能量函数序列V,增广能量函数序列W
if nargin<4 % 输入参数个数
    h=0.01;
end
if size(tspan)==[1,2]
    t0=tspan(1);
    tn=tspan(2);
else
    error(message('MATLAB:Euler:WrongDimensionOfTspan'));
end
n=floor((tn-t0)/h);%求步数
t(1)=t0;%时间起点
x(:,1)=x0;%第一列赋初值，可以是向量，代表不同的初始值
P=[1 0.25;0.25 1];
V(:,1)=x0'*P*x0; % 能量函数
W(:,1)=x0'*P*x0; % 增广能量函数
eta=0; % 内部动态变量初值
for i=1:n
  t(i+1)=t(i)+h;
  [dx,deta]=ufunc(t(i),x(:,i),eta(:,i));
  x(:,i+1)=x(:,i)+h*dx;
  V(:,i+1)=x(:,i+1)'*P*x(:,i+1);
  eta(:,i+1)=eta(:,i)+h*deta; % 内部变量的演化
  W(:,i+1)=x(:,i+1)'*P*x(:,i+1)+eta(:,i+1);
end