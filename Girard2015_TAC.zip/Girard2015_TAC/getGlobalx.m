function r = getGlobalx     % 读取
global x;
r = x;
end
