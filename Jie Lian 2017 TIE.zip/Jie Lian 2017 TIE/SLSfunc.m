%% 系统动态方程
function dx = SLSfunc(t,swi_t,x,x_temp)
% 输入参数：时间t，系统切换信号sigma(t)，状态x(t)，采样时刻状态x(t_k)和sigma(t_k)
% 输出参数：状态导数dx
A1=[1 0;0 -1];B1=[1;0];K1=[-2 0]; % 系统矩阵
A2=[0 1;-1 0];B2=[0;1];K2=[0 -1];

switch swi_t  % 被控对象切换信号
    case 1
        A=A1;B=B1;
    case 2
        A=A2;B=B2;
end
switch x_temp(4) % 控制器切换信号
    case 1
        K=K1;
    case 2
        K=K2;
end
dx=A*x+B*K*x_temp(2:3); % 系统状态方程

