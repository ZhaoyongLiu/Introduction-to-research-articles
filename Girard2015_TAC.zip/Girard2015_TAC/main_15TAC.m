%% 动态事件触发控制
% 参考文献：Dynamic Triggering Mechanisms for Event-Triggered Control,Antoine Girard,TAC,2015.
% 作者：Liu Zhaoyong
% 修改记录：2022.8.21  版本号：v1.0--程序编写
%          2022.9.5           v2.0--动态事件触发
clc;        
clear; clear global trigger_times  trigger_times_Dyn trigger_times_Self
close all;tic
%% 初始化条件
h = 0.001;  % 仿真步长
% x0 = [10*cos(2*pi/30); 10*sin(2*pi/30)];  % 初始状态
x0 = [10; 0];  % 初始状态
setGlobalx(x0); 
global trigger_times; % 静态事件触发时刻
trigger_times(1)=0; 
global trigger_times_Dyn; % 动态事件触发时刻
trigger_times_Dyn(1)=0;
global trigger_times_Self; % 自触发时刻
trigger_times_Self(1)=0;
sigma=0.1; kappa=0.48;
P=[1 0.25;0.25 1];
%% 静态事件触发控制
[t,x,V] = Simul(@Static_ETC2015,[0 10],x0,h);     % Euler法 事件触发控制仿真
[tf,index]=ismember(trigger_times,t);
Vt=V(index); % 事件触发时刻能量
Vfun= x0'*P*x0*exp((sigma-1)*kappa*t);
%% 动态事件触发控制
setGlobalx(x0); % 重置状态初值
[t,x_Dyn,eta,V_Dyn,W] = Simul_Dyn(@Dynamic_ETC2015,[0 10],x0,h);     % Euler法 事件触发控制仿真
[tf_Dyn,index_Dyn]=ismember(trigger_times_Dyn,t);
Vt_Dyn=V_Dyn(index_Dyn); % 动态事件触发时刻能量
%% 自触发控制
setGlobalx(x0); % 重置状态初值
[t,x_Self,V_Self] = Simul_Self(@Self_ETC2015,[0 10],x0,h);     % Euler法 事件触发控制仿真
[tf_Self,index_Self]=ismember(trigger_times_Self,t);
Vt_Self=V_Self(index_Self); % 动态事件触发时刻能量
%% 绘图
figure(1);
plot(t, x(1,:), 'r',t, x(2,:),'b','Linewidth',1.2)   % 系统状态
legend('$x_1$','$x_2$','Interpreter','Latex','Fontsize',11);
xlabel('time(s)');
figure(2)
plot(t, V, 'b','Linewidth',1.2)   % 能量函数
hold on;
plot(t, Vfun,'--','Color',[0 0.9 0]);
plot(trigger_times,Vt,'bo')
legend('V(x(t))','V(x(0))e^{(\sigma-1)\kappa t}','Execution times','Fontsize',11);
%%
figure(3);
plot(t, x_Dyn(1,:), 'r',t, x_Dyn(2,:),'b','Linewidth',1.2)   % 系统状态
legend('$x_1$','$x_2$','Interpreter','Latex','Fontsize',11);
xlabel('time(s)');
figure(4)
plot(t, V_Dyn, 'b','Linewidth',1.2)   % 能量函数
hold on;
plot(t, W,'Color',[0.9 0 0]);
plot(t, Vfun,'--','Color',[0 0.9 0]);
plot(trigger_times_Dyn,Vt_Dyn,'bo')
legend('V(x(t))','W(x(t),\eta(t))','V(x(0))e^{(\sigma-1)\kappa t}','Execution times','Fontsize',11);
%%
figure(5);
plot(t, x_Self(1,:), 'r',t, x_Self(2,:),'b','Linewidth',1.2)   % 系统状态
legend('$x_1$','$x_2$','Interpreter','Latex','Fontsize',11);
xlabel('time(s)');
figure(6)
plot(t, V_Self, 'b','Linewidth',1.2)   % 能量函数
hold on;
plot(t, Vfun,'--','Color',[0 0.9 0]);
plot(trigger_times_Self,Vt_Self,'bo')
legend('V(x(t))','V(x(0))e^{(\sigma-1)\kappa t}','Execution times','Fontsize',11);
toc