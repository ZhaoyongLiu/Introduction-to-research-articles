%% Forward Euler Method for Solving Differential Equations

function [t,x,u,x_tk]=ASDC_SLS(SLSfunc,tspan,x0,swi_t,T,h)
% Input arguments: function name，time span，initial state，switching signal，sampling period，step size
% Output arguments: time，state，input, sampled state

t0=tspan(1);
tf=tspan(2);
n=floor((tf-t0)/h); 

t=zeros(1,n+1);t(1)=t0;  
x=zeros(2,n+1);x(:,1)=x0;  % system state
x_tk=[];x_tk(:,1)=[t0;x0;swi_t(2,1)];  % t_k,x(t_k),sigma(t_k)
x_temp=x_tk(:,1);
K2=[0 -1];
u=zeros(1,n+1);u(1)=K2*x0;  % input

for i=1:n
  t_temp=t(i); % current time
  t(i+1)=t(i)+h;
  if mod(roundn(t(i),-3),T)==0 && t(i)~=0  % t_k,sampling 
      x_tk=[x_tk,[t(i);x(:,i);swi_t(2,i)]];
      x_temp=x_tk(:,end);  % x(t_k) and sigma(t_k)
  end
  % roundn(a,-3)--retain 3 decimal places
  dx=SLSfunc(t(i),swi_t(2,i),x(:,i),x_temp); % t,sigma(t),x(t),x(t_k),sigma(t_k)
  x(:,i+1)=x(:,i)+h*dx;   
end