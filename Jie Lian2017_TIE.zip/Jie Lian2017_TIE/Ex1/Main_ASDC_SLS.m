%% This MATLAB program performs a numerical simulation on Example 1 in the paper.
% Jie Lian,Can Li,and Biao Xia,"Sampled-Data Control of Switched Linear Systems With Application to an F-18 Aircraft",IEEE TIE, vol.64, no.2, pp. 1332-1340, 2017.
%%
clc; clear; 
close all;tic

%% Initialization parameters
h = 0.001;  % step size
t0=0;tf=25;
t=t0:h:tf;   % duration
x0 = [2; 2];  % initial state
T=0.5;   % sampling period

%% Switching signal
swi_seq=[1.2 1.9 2.5 3.75 5.6 8 13 17.5 21.5]; % switching time sequence
swi_t=SwiFcn_ASDC(swi_seq,t);
figure(1)
plot(t,swi_t(2,:),'k','linewidth',1.3);axis([-inf inf 0.8 2.2]);
xlabel('time(s)')
set(gca,'Linewidth',1,'Fontsize',11);

%% Asynchronous sampled-data control
[t,x,u,x_tk]=ASDC_SLS(@SLSfunc,[t0 tf],x0,swi_t,T,h); % Euler method

%% Plot
swi_temp=zeros(1,length(swi_seq));
for k=1:length(swi_seq) 
    swi_temp(k)=find(abs(swi_t(1,:)-swi_seq(k))<0.00001);
end
x_swi=x(:,swi_temp); % system state at switching times

figure(2)
plot(t,x(1,:),'k',t,x(2,:),'k--','Linewidth',1.3)
hold on;
plot(swi_seq,x_swi,'r*');
legend('state $x_1$','state $x_2$','switches','Interpreter','Latex','Fontsize',14)
xlabel('time(s)');ylabel('states $x_1,x_2$','Interpreter','Latex')
axis([-inf tf -2 4]);
set(gca,'Linewidth',1,'Fontsize',13);
toc