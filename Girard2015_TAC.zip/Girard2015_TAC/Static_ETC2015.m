%% 静态事件触发
function dx = Static_ETC2015(t,x)
global trigger_times;
A = [0 1; -2 3];  %系统参数矩阵
B = [0; 1];       %系统参数矩阵
K = [1 -4];       %反馈矩阵
P=[1 0.25;0.25 1];
Q=[0.5 0.25;0.25 1.5];
xt = getGlobalx;
e = xt-x;
sigma=0.1; % 事件触发参数
if sigma*x'*Q*x-2*x'*P*B*K*e<0  % 事件触发条件
   setGlobalx(x); 
   trigger_times=[trigger_times,t];
%    %disp(t);
%    dlmwrite('ETC.txt',1,'-append');
%    dlmwrite('norme.txt',norm(e),'-append');
%    trigger_times=trigger_times+1;
else
%     dlmwrite('ETC.txt',0,'-append');
%     dlmwrite('norme.txt',norm(e),'-append'); 
end
xt = getGlobalx;
u = K*xt;
dx=A*x+B*u;
end